[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/mxYpjcnI)
# OKC Thunder Technical Assessment

### Internship Program Disclosures

* You must be eligible to work in the United States to qualify for this internship.
  
* The pay for this internship is the greater of your local minimum wage and $13/hour.

* This application is for the purposes of an internship taking place in the Spring, Summer, or Fall of 2025.

### Task

Your task is to implement find_qualified_games in game_finder.py. Detailed instructions for this technical assessment can be found in game_finder.py. Some sample test cases are provided in the `tests` folder, but additional ones may be used to evaluate your code.


# Questions?

Email datasolutions@okcthunder.com